<?php
     function welcomeMessage(){
        echo "Welcome. This is the backgammon game Feuga. Created By Anastasia Vasileiadou";
    }


?>