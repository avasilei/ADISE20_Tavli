<?php

interface Player

{
    //Set the color of the player
    public function setColor($color);
    //Move of the player
    public function PlayerMove($Game);
}
