<?php
class Movement{

    private $startingPosition;

    //private $numberofPoints;                to check if neccesary

    public function getStartingPosition(){
        return $this->startingPosition;
    }

    public function setStartingPosition($startingPosition){
        $this->startingPosition = $startingPosition;
    }

    /*public function getNumberPosition(){
        return $this->$numberofPoints;      to check if neccesary
    }
    */

    /*
    public function setNumberPotision($numberofPoints){
        $this->numberofPoints = $numberofPoints;    to check if neccesary
    }
    */

}
