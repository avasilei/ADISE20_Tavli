<?php

class PawnConstructor{

    public function create($color){
        return new Pawn($color);
    }
}
